# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasRegressor
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
import numpy
import pandas

#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the boston housing dataset
dataframe = pandas.read_csv("housing.csv", delim_whitespace=True, header=None)
dataset = dataframe.values

#split to input and output arrays
X = dataset[:,0:13]
y = dataset[:,13]


# define base model
def baseline_model():
	# create model
	model = Sequential()
	model.add(Dense(13, input_dim=13, kernel_initializer='normal', activation='relu'))
	model.add(Dense(1, kernel_initializer='normal'))
	# Compile model
	model.compile(loss='mean_squared_error', optimizer='adam')
	return model

    
#create model using KerasRegressor class
estimator = KerasRegressor(build_fn=baseline_model, epochs=100, batch_size=5, verbose=0)

#doing k-fold cross validation and get the results
kfold = KFold(n_splits=10, random_state=seed)
results = cross_val_score(estimator, X, y, cv=kfold)

print("Results: %.2f (%.2f) MSE" % (results.mean(), results.std()))

















