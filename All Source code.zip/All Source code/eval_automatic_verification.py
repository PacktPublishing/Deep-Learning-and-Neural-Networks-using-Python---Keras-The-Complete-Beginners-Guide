# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
import numpy


#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the pima indian dataset
dataset = numpy.loadtxt("pima-indians-diabetes.csv", delimiter=",")

#split to input and output arrays
X = dataset[:,0:8]
Y = dataset[:,8]

#creating the model
model = Sequential()
model.add(Dense(12, input_dim=8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(1, kernel_initializer='uniform', activation='sigmoid'))

#compile the model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

#fit the model
# to disable the scrolling display during running, use verbose=0 arument in fit()
model.fit(X, Y, validation_split=0.33, epochs=150, batch_size=10)

#evaluate the model
scores = model.evaluate(X, Y)
print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))




















