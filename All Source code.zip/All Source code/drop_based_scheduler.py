# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import LabelEncoder
import numpy
import pandas
import math
from keras.optimizers import SGD
from keras.callbacks import LearningRateScheduler

# learning rate schedule function
def step_decay(epoch):
    initial_lrate = 0.1
    drop = 0.5
    epochs_drop = 10.0
    lrate = initial_lrate * math.pow(drop, math.floor((1+epoch)/epochs_drop))
    return lrate

#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the sonar dataset
dataframe = pandas.read_csv("ionosphere.csv", header=None)
dataset = dataframe.values

#split to input and output arrays
X = dataset[:,0:34].astype(float)
y = dataset[:,34]

#for one-hot encoding
#encode the output class values as integers
encoder = LabelEncoder()
encoder.fit(y)
encoded_y = encoder.transform(y)


#creating the model
model = Sequential()
model.add(Dense(34, input_dim=34, activation='relu'))
model.add(Dense(1, activation='sigmoid'))


#compile the model
momentum = 0.9
sgd = SGD(lr=0.0, momentum=momentum, decay=0.0, nesterov=False)
model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['accuracy'])

#learning rate schedule callback
lrate = LearningRateScheduler(step_decay)
callbacks_list = [lrate]

#fit the model
model.fit(X, encoded_y, validation_split=0.33, epochs=50, batch_size=18, callbacks = callbacks_list)
















