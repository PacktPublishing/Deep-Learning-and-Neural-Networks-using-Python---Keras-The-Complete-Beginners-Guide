# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from sklearn.model_selection import StratifiedKFold
import numpy


#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the pima indian dataset
dataset = numpy.loadtxt("pima-indians-diabetes.csv", delimiter=",")

#split to input and output arrays
X = dataset[:,0:8]
y = dataset[:,8]

#define the k-fold (10-fold) cross validation
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)

cvscores = []

for i, (train, test) in enumerate(kfold.split(X,y)):
    #creating the model
    model = Sequential()
    model.add(Dense(12, input_dim=8, kernel_initializer='uniform', activation='relu'))
    model.add(Dense(8, kernel_initializer='uniform', activation='relu'))
    model.add(Dense(1, kernel_initializer='uniform', activation='sigmoid'))
    
    #compile the model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    
    #fit the model
    # to disable the scrolling display during running, use verbose=0 arument in fit()
    model.fit(X[train], y[train], epochs=150, batch_size=10)
    
    #evaluate the model
    scores = model.evaluate(X[test], y[test])
    print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))
    cvscores.append(scores[1]*100)
    
print("%.2f%% (+/- %.2f%%)" % (numpy.mean(cvscores), numpy.std(cvscores)))    





















