# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
import numpy
import matplotlib.pyplot as plt


#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the pima indian dataset
dataset = numpy.loadtxt("pima-indians-diabetes.csv", delimiter=",")

#split to input and output arrays
X = dataset[:,0:8]
Y = dataset[:,8]

#creating the model
model = Sequential()
model.add(Dense(12, input_dim=8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(1, kernel_initializer='uniform', activation='sigmoid'))

#compile the model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

#collect history returned by the fit function
history = model.fit(X, Y, validation_split=0.33, epochs=150, batch_size=10, verbose=0)

#print and list the metrics in history
print(history.history.keys())

#plot the summary of accuracy in history during validation and training
fig1 = plt.figure(1)
plt.plot(history.history['acc'])
plt.plot(history.history['val_acc'])
plt.title('Model Accuracy')
plt.ylabel('Accuracy')
plt.xlabel('Epoch')
plt.legend(['training', 'testing'], loc='upper left')


#plot the summary of loss in history during validation and training
fig2 = plt.figure(2)
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('Model Loss')
plt.ylabel('Loss')
plt.xlabel('Epoch')
plt.legend(['training', 'testing'], loc='upper left')

plt.show()












