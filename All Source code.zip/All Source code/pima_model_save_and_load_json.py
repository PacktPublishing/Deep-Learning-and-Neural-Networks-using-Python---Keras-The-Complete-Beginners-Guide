# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
import numpy
from keras.models import model_from_json


#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the pima indian dataset
dataset = numpy.loadtxt("pima-indians-diabetes.csv", delimiter=",")

#split to input and output arrays
X = dataset[:,0:8]
Y = dataset[:,8]

#creating the model
model = Sequential()
model.add(Dense(12, input_dim=8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(1, kernel_initializer='uniform', activation='sigmoid'))

#compile the model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

#fit the model
model.fit(X, Y, epochs=150, batch_size=10)

#evaluate the model
scores = model.evaluate(X, Y)
print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))

#save model as Json
model_json = model.to_json()
with open("model_pima.json", "w") as json_file:
    json_file.write(model_json)

#save the weights as hdf5
model.save_weights("model_pima.h5")

print("Saved the model to the computer")


#load the json from the file and recreate the model
json_file = open('model_pima.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)

#load the weights from hdf5 file
loaded_model.load_weights("model_pima.h5")
print("Loaded model from the computer")



















