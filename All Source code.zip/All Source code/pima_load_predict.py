# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import model_from_yaml
from numpy import array




#load the yaml from the file and recreate the model
yaml_file = open('model_pima.yaml', 'r')
loaded_model_yaml = yaml_file.read()
yaml_file.close()
loaded_model = model_from_yaml(loaded_model_yaml)

#load the weights from hdf5 file
loaded_model.load_weights("model_pima.h5")
print("Loaded model from the computer")

### Load the model from File Here ####
# predict the output
# new instance where we do not know the answer
Xnew = array([[0,180,66,39,0,42.0,1.893,25]])

# make a prediction
ynew = loaded_model.predict_classes(Xnew)
# show the inputs and predicted outputs
print("X=%s, Predicted=%s" % (Xnew[0], ynew[0]))

















