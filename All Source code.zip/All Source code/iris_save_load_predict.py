# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from keras.utils import np_utils
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
import numpy
import pandas
from keras.models import model_from_json
from numpy import array

#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the iris flowers dataset
dataframe = pandas.read_csv("iris.csv", header=None)
dataset = dataframe.values

#split to input and output arrays
X = dataset[:,0:4]
y = dataset[:,4]

#for one-hot encoding
#encode the output class values as integers
encoder = LabelEncoder()
encoder.fit(y)
encoded_y = encoder.transform(y)
#do the one-hot encoding
dummy_y = np_utils.to_categorical(encoded_y)



def baseline_model(optimizer='rmsprop', init='glorot_uniform'):
    #creating the model
    model = Sequential()
    model.add(Dense(8, input_dim=4, activation='relu'))
    model.add(Dense(3, activation='softmax'))
    #compile the model
    model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
    
#create model using KerasClassifer class
estimator = KerasClassifier(build_fn=baseline_model, epochs=200, batch_size=5, verbose=0)

#doing k-fold cross validation and get the results
kfold = KFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(estimator, X, dummy_y, cv=kfold)

print("Base-line: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))


estimator.fit(X, y)
# serialize model to JSON
model_json = estimator.model.to_json()
with open("model_iris.json", "w") as json_file:
    json_file.write(model_json)


# serialize weights to HDF5
estimator.model.save_weights("model_iris.h5")
print("Saved model to disk")



# load json and create model
json_file = open('model_iris.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)


# load weights into new model
loaded_model.load_weights("model_iris.h5")
print("Loaded model from disk")


# predict the output
# new instance where we do not know the answer
Xnew = array([[6.3,2.5,5,1.9]])

# make a prediction
ynew = loaded_model.predict_classes(Xnew)
# show the inputs and predicted outputs
print("X=%s, Predicted=%s" % (Xnew[0], ynew[0]))
print("X=%s, Predicted=%s" % (Xnew[0], numpy.unique(y)[ynew[0]]))











