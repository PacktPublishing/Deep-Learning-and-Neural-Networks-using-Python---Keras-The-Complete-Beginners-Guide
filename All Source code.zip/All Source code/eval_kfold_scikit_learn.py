# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import cross_val_score
import numpy

#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

def create_model():
    #creating the model
    model = Sequential()
    model.add(Dense(12, input_dim=8, kernel_initializer='uniform', activation='relu'))
    model.add(Dense(8, kernel_initializer='uniform', activation='relu'))
    model.add(Dense(1, kernel_initializer='uniform', activation='sigmoid'))
    #compile the model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
    
#loading the pima indian dataset
dataset = numpy.loadtxt("pima-indians-diabetes.csv", delimiter=",")

#split to input and output arrays
X = dataset[:,0:8]
y = dataset[:,8]

#define the k-fold (10-fold) cross validation
kfold = StratifiedKFold(n_splits=10, shuffle=True, random_state=seed)

#create model using KerasClassifer class
model = KerasClassifier(build_fn=create_model, epochs=150, batch_size=10)

#using the cross_val_score for calulating the kfold validation
results = cross_val_score(model, X, y, cv=kfold)
print(results.mean())



















