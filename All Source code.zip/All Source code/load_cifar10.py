# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
from keras.datasets import cifar10
import matplotlib.pyplot as pyplot
#from PIL import Image
from scipy.misc import toimage

#load/download the cifar10 dataset
(X_train, y_train), (X_test, y_test) = cifar10.load_data(label_mode='fine')
#plotting the sample 9 images in a 3x3 grid
for i in range(0, 9):
    pyplot.subplot(330 + 1 + i)
    #pyplot.imshow(Image.fromarray(X_train[i]))
    pyplot.imshow(toimage(X_train[i]))

#display the plot
pyplot.show()