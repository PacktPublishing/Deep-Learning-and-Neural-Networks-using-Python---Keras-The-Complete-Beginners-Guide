# -*- coding: utf-8 -*-
"""

@author: abhilash
"""

from keras.models import model_from_json
from keras.preprocessing.image import img_to_array, load_img
from keras import backend as K
K.set_image_dim_ordering('th')


# load json and create model
json_file = open('model_cifar10.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)


# load weights into new model
loaded_model.load_weights("model_cifar10.h5")
print("Loaded model from disk")



cifar_classes = ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

# Load the image to predict
img = load_img('test_images/cat2.jpg')
img = img.resize((32,32))
im2arr = img_to_array(img)
im2arr = im2arr.reshape((1,) + im2arr.shape)


#Do prediction
y_pred = loaded_model.predict(im2arr)
print("The predicted object is: ")
print(str([cifar_classes[y_pred.argmax()]]))



