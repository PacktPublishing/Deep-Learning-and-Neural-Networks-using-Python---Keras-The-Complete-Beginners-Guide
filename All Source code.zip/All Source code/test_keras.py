# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
from keras import backend
print(backend._BACKEND)
