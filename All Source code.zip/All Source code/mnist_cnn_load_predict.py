# -*- coding: utf-8 -*-
"""

@author: abhilash
"""

from keras.models import model_from_json
from PIL import Image
import numpy

# load json and create model
json_file = open('model_mnist.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)


# load weights into new model
loaded_model.load_weights("model_mnist.h5")
print("Loaded model from disk")

# Load the image to predict
img = Image.open('handwritten_numbers/two.png').convert("L")
img = img.resize((28,28))
im2arr = numpy.array(img)
im2arr = im2arr.reshape(1,28,28,1)

#Do prediction
y_pred = loaded_model.predict(im2arr)
print("The predicted digit is: ")
print(y_pred.argmax())
