# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasRegressor
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
import numpy
import pandas
from keras.models import model_from_json
from numpy import array

#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the boston housing dataset
dataframe = pandas.read_csv("housing.csv", delim_whitespace=True, header=None)
dataset = dataframe.values

#split to input and output arrays
X = dataset[:,0:13]
y = dataset[:,13]


# define base model
def baseline_model():
	# create model
	model = Sequential()
	model.add(Dense(13, input_dim=13, kernel_initializer='normal', activation='relu'))
	model.add(Dense(1, kernel_initializer='normal'))
	# Compile model
	model.compile(loss='mean_squared_error', optimizer='adam')
	return model

    
#create model using KerasRegressor class
estimator = KerasRegressor(build_fn=baseline_model, epochs=100, batch_size=5, verbose=0)

#doing k-fold cross validation and get the results
kfold = KFold(n_splits=10, random_state=seed)
results = cross_val_score(estimator, X, y, cv=kfold)

print("Results: %.2f (%.2f) MSE" % (results.mean(), results.std()))


estimator.fit(X, y)
# serialize model to JSON
model_json = estimator.model.to_json()
with open("model_boston.json", "w") as json_file:
    json_file.write(model_json)


# serialize weights to HDF5
estimator.model.save_weights("model_boston.h5")
print("Saved model to disk")


# load json and create model
json_file = open('model_boston.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
loaded_model = model_from_json(loaded_model_json)


# load weights into new model
loaded_model.load_weights("model_boston.h5")
print("Loaded model from disk")


# predict the output from new instance where we do not know the answer
Xnew = array([[0.01965,80,1.76,"0",0.385,6.23,31.5,9.0892,1,241,18.2,341.6,12.93]])

# convert data type of array to float64 
Xnew = numpy.array(Xnew, dtype=numpy.float64)


# make a prediction
ynew = loaded_model.predict(Xnew)
# show the inputs and predicted outputs
print("X=%s, Predicted=%s" % (Xnew[0], ynew[0]))








