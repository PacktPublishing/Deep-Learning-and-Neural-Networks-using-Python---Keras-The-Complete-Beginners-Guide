# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
import numpy
from keras.models import model_from_yaml


#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the pima indian dataset
dataset = numpy.loadtxt("pima-indians-diabetes.csv", delimiter=",")

#split to input and output arrays
X = dataset[:,0:8]
Y = dataset[:,8]

#creating the model
model = Sequential()
model.add(Dense(12, input_dim=8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(8, kernel_initializer='uniform', activation='relu'))
model.add(Dense(1, kernel_initializer='uniform', activation='sigmoid'))

#compile the model
model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

#fit the model
model.fit(X, Y, epochs=150, batch_size=10)

#evaluate the model
scores = model.evaluate(X, Y)
print("%s: %.2f%%" % (model.metrics_names[1], scores[1]*100))

#save model as YAML
model_yaml = model.to_yaml()
with open("model_pima.yaml", "w") as yaml_file:
    yaml_file.write(model_yaml)

#save the weights as hdf5
model.save_weights("model_pima.h5")

print("Saved the model to the computer")


#load the yaml from the file and recreate the model
yaml_file = open('model_pima.yaml', 'r')
loaded_model_yaml = yaml_file.read()
yaml_file.close()
loaded_model = model_from_yaml(loaded_model_yaml)

#load the weights from hdf5 file
loaded_model.load_weights("model_pima.h5")
print("Loaded model from the computer")

#compile the model
loaded_model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

#fit the model
loaded_model.fit(X, Y, epochs=150, batch_size=10)
#evaluate the model
scores = loaded_model.evaluate(X, Y)
print("%s: %.2f%%" % (loaded_model.metrics_names[1], scores[1]*100))
















