# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
import theano
from theano import tensor

#declare two symbolic floating-point scalars
a = tensor.dscalar()
b = tensor.dscalar()
#creating a simple symbolic expression
c = a + b
#convert expression into callable object
f = theano.function([a,b], c)
#binding 1.5 to a and 2.5 to b and evaluating c
result = f(1.5, 2.5)
print(result)