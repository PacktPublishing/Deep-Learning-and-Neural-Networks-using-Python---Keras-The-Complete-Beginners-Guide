# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
from keras.datasets import mnist
import matplotlib.pyplot as plt

#load/download the MNIST dataset
(X_train, y_train), (X_test, y_test) = mnist.load_data()
#plotting the sample 9 imags in a 3x3 grid
for i in range(0,9):
    plt.subplot(330 + 1 + i)
    plt.imshow(X_train[i], cmap=plt.get_cmap('gray'))
#display the plot
plt.show()