# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from sklearn.preprocessing import LabelEncoder
import numpy
import pandas
from keras.optimizers import SGD

#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the sonar dataset
dataframe = pandas.read_csv("ionosphere.csv", header=None)
dataset = dataframe.values

#split to input and output arrays
X = dataset[:,0:34].astype(float)
y = dataset[:,34]

#for one-hot encoding
#encode the output class values as integers
encoder = LabelEncoder()
encoder.fit(y)
encoded_y = encoder.transform(y)


#creating the model
model = Sequential()
model.add(Dense(34, input_dim=34, activation='relu'))
model.add(Dense(1, activation='sigmoid'))


#compile the model
epochs = 50
learning_rate = 0.1
decay_rate = learning_rate / epochs
momentum = 0.8
sgd = SGD(lr=learning_rate, momentum=momentum, decay=decay_rate, nesterov=False)
model.compile(loss='binary_crossentropy', optimizer=sgd, metrics=['accuracy'])

#fit the model
model.fit(X, encoded_y, validation_split=0.33, epochs=epochs, batch_size=28)
















