# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
#importing the required libraries
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
import numpy
import pandas

#fix the seed value for keeping the result uniform
seed = 7
numpy.random.seed(seed)

#loading the sonar dataset
dataframe = pandas.read_csv("sonar.csv", header=None)
dataset = dataframe.values

#split to input and output arrays
X = dataset[:,0:60].astype(float)
y = dataset[:,60]

#for one-hot encoding
#encode the output class values as integers
encoder = LabelEncoder()
encoder.fit(y)
encoded_y = encoder.transform(y)


def create_baseline():
    #creating the model
    model = Sequential()
    model.add(Dense(60, input_dim=60, kernel_initializer='normal', activation='relu'))
    model.add(Dense(30, kernel_initializer='normal', activation='relu'))
    model.add(Dense(1, kernel_initializer='normal', activation='sigmoid'))
    #compile the model
    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])
    return model
    
#create model using KerasClassifer class
estimator = KerasClassifier(build_fn=create_baseline, epochs=100, batch_size=5, verbose=0)

#doing k-fold cross validation and get the results
kfold = KFold(n_splits=10, shuffle=True, random_state=seed)
results = cross_val_score(estimator, X, encoded_y, cv=kfold)

print("Large: %.2f%% (%.2f%%)" % (results.mean()*100, results.std()*100))

















