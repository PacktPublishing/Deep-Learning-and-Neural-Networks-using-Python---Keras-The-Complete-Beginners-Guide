# -*- coding: utf-8 -*-
"""

@author: abhilash
"""
import tensorflow as tf

#declare two symbolic floating point scalars
a = tf.placeholder(tf.float32)
b = tf.placeholder(tf.float32)

#create a simple symbolic expression using the add function
add = tf.add(a, b)
sess = tf.Session()
#binding the values and evaluate result
binding = {a: 1.5, b: 2.5}
c = sess.run(add, feed_dict=binding)
print(c)